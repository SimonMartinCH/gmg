//background layer definitions. Find others basemaps on https://leaflet-extras.github.io/leaflet-providers/preview/
var couche_osm = L.tileLayer('http://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png', {
	maxZoom: 19,
	attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>, Tiles courtesy of <a href="http://hot.openstreetmap.org/" target="_blank">Humanitarian OpenStreetMap Team</a>'
});
var couche_sat = L.tileLayer('http://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
  	attribution: '&copy; Esri &mdash; <a href="http://www.arcgis.com/home/item.html?id=c1c2090ed8594e0193194b750d0d5f83" target="_blank">Références complètes des sources</a>'
});

//creation and parameters of the Leaflet map
var map = L.map('map', {
    center: [46.288, 7.234], //coordinates of map center when loaded (decimal degrees - WGS84)
    zoom: 12, //zoom level when map is loaded
    maxZoom: 16, //maximum zoom level
    minZoom: 11, //minimum zoom level
    //maxBounds: [[46.2, 7.1], [46.35, 7.4]], //add limits to your map: the user cannot drag the map outside those limits
    //doubleClickZoom: false,
    layers : [couche_osm] //define the background you want to show when map is loaded
});

//add background layer selector
var selecteur_couches = {
    "Base map": couche_osm,
    "Satellite": couche_sat
};
L.control.layers(selecteur_couches, {}).addTo(map);


//link a popup to the features from geoJSON
function onEachFeature(feature, layer) {
    // does this feature have a property named popupContent?
    if (feature.properties && feature.properties.popupContent) {
        layer.bindPopup(feature.properties.popupContent);
    }
}

//add get data from the POINT geoJSON file and create new point features on the map (icon name and popup content are stored in the geoJSON)
$.getJSON('geodata/point_GP.geojson', function(data){
	var point_layer = L.geoJson(data, {
			onEachFeature: function (feature, layer) {
				layer.bindPopup(feature.properties.DESCR); 	     //link a popup to the features with data taken from geoJSON (DESCR attribute can be html)
			},
	    pointToLayer: function (feature, latlng) {
				var spectific_icon = L.icon({
				    iconUrl: 'icons/'+ feature.properties.ICON +'.png', //the name of the picture file for the specific icon should be exactly the one written in the ICON attribute of the point feature
				    iconSize: [20, 20],
				    iconAnchor: [10, 10],
				});
   			return L.marker(latlng, {icon: spectific_icon});
				}
			})
	point_layer.addTo(map);
});

//add get data from the LINE geoJSON file and create new line features on the map (color and popup content are stored in the geoJSON)
$.getJSON('geodata/line_GP.geojson', function(data){
	var line_layer = L.geoJson(data, {
	     //link a popup to the features with data taken from geoJSON
	    onEachFeature: function (feature, layer) {
				layer.bindPopup(feature.properties.PROCESS+'<br>'+feature.properties.FORM);
			},
		//apply different style according to the PROCESS attribute
	   	style: function(feature) {
			switch (feature.properties.PROCESS) {
				case 'STR': return {color: 'red', weight: 1, opacity: 1};
				case 'HYD': return {color: 'cyan', weight: 1, opacity: 1};
				case 'GRA': return {color: 'orange', weight: 1, opacity: 1};
				case 'FLU': return {color: 'green', weight: 1, opacity: 1};
				case 'GLA': return {color: 'purple', weight: 1, opacity: 1};
				case 'PGL': return {color: 'pink', weight: 1, opacity: 1};
				case 'ANT': return {color: 'grey', weight: 1, opacity: 1};
			}
    	}
	})
	line_layer.addTo(map);
});

//add get data from the POLYGON geoJSON file and create new polygon features on the map (color and popup content are stored in the geoJSON)
$.getJSON('geodata/surf_GP.geojson', function(data){
	var polygon_layer = L.geoJson(data, {
	     //link a popup to the features with data taken from geoJSON
	    onEachFeature: function (feature, layer) {
				layer.bindPopup(feature.properties.PROCESS+'<br>'+feature.properties.FORM);
			},
		//apply different style according to the PROCESS attribute
	   	style: function(feature) {
			switch (feature.properties.PROCESS) {
				case 'HYD': return {color: 'cyan', weight: 0.1, opacity: 1, fillOpacity: 0.2};
				case 'GRA': return {color: 'orange', weight: 0.1, opacity: 1, fillOpacity: 0.7};
				case 'FLU': return {color: 'green', weight: 0.1, opacity: 1, fillOpacity: 0.7};
				case 'GLA': return {color: 'purple', weight: 0.1, opacity: 1, fillOpacity: 0.7};
				case 'PGL': return {color: 'pink', weight: 0.1, opacity: 1, fillOpacity: 0.7};
				case 'ANT': return {color: 'grey', weight: 0.1, opacity: 1, fillOpacity: 0.7};
			}
    	}
	})
	polygon_layer.addTo(map);
});
